--字典类型表数据初始化 

SELECT nextval ( 'dict_type_id_dict_type_seq' );
INSERT INTO PUBLIC.dict_type ( id_dict_type, type_name, type_code, remark, created_by, created_date, updated_by, updated_date )
VALUES
	( 1, '业务类型', 'business_type', '', 'system', now( ), 'system', now( ) );
	
--字典表数据初始化 

SELECT nextval ( 'dictionary_id_dictionary_seq' );
INSERT INTO PUBLIC.DICTIONARY ( id_dictionary, NAME, CODE, type_code, remark, created_by, created_date, updated_by, updated_date )
VALUES
	( 1, '年检代办', '01', 'business_type', '', 'system', now( ), 'system', now( ) );