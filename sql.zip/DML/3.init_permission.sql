--permission表插入数据
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );
SELECT nextval ( 'permission_id_permission_seq' );

--服务类型
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	(1, 'dict', '年检业务类型', '年检业务类型', 1, TRUE, 'system', 'system' );

--menu
--一级菜单权限
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	(2, 'menu', '权限管理', '权限管理菜单', 1, TRUE, 'system', 'system' );

INSERT INTO permission ( id_permission,permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	(3, 'menu', '服务管理', '服务管理菜单', 2, TRUE, 'system', 'system' );

	INSERT INTO permission ( id_permission,permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	(4, 'menu', '年检调度中心', '年检调度中心菜单', 3, TRUE, 'system', 'system' );
	

--二级菜单权限

INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	( 5,'menu', '用户管理', '用户管理菜单', 4, TRUE, 'system', 'system' );
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	(6, 'menu', '角色管理', '角色管理菜单', 5, TRUE, 'system', 'system' );

INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	(7, 'menu', '服务商管理', '服务商管理菜单', 6, TRUE, 'system', 'system' );
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	(8, 'menu', '服务员管理', '服务员管理菜单', 7, TRUE, 'system', 'system' );
	
	INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	( 9,'menu', '所有任务', '所有任务菜单', 8, TRUE, 'system', 'system' );
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	( 10,'menu', '我的任务', '我的任务菜单', 9, TRUE, 'system', 'system' );
	

--三级菜单权限

--用户管理
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	(11, 'menu', '查看', '用户管理菜单-》查看操作', 10, TRUE, 'system', 'system' );
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	(12, 'menu', '添加用户', '用户管理菜单-》添加用户操作操作', 11, TRUE, 'system', 'system' );
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	( 13,'menu', '编辑', '用户管理菜单-》编辑操作', 12, TRUE, 'system', 'system' );
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	( 14,'menu', '启用/禁用', '用户管理菜单-》启用禁用操作', 13, TRUE, 'system', 'system' );
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	(15, 'menu', '机构用户', '用户管理菜单-》机构用户操作', 14, TRUE, 'system', 'system' );
	
	
--角色管理
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	( 16,'menu', '查看', '角色管理菜单-》查看操作', 15, TRUE, 'system', 'system' );
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	( 17,'menu', '添加角色', '角色管理菜单-》添加角色操作', 16, TRUE, 'system', 'system' );
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	( 18,'menu', '编辑', '角色管理菜单-》编辑操作', 17, TRUE, 'system', 'system' );
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	( 19,'menu', '删除', '角色管理菜单-》删除操作', 18, TRUE, 'system', 'system' );

	
--服务商管理
	
	INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	( 20,'menu', '查看', '服务商管理菜单-》查看操作', 19, TRUE, 'system', 'system' );
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	( 21,'menu', '添加服务商', '服务商管理菜单-》添加服务商操作', 20, TRUE, 'system', 'system' );
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	( 22,'menu', '编辑', '服务商管理菜单-》编辑操作', 21, TRUE, 'system', 'system' );
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	( 23,'menu', '启用/禁用', '服务商管理菜单-》启用/禁用操作', 22, TRUE, 'system', 'system' );
	INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	( 24,'menu', '承接项目', '服务商管理菜单-》承接项目操作', 23, TRUE, 'system', 'system' );
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	(25, 'menu', '服务员列表', '服务商管理菜单-》服务员列表操作', 24, TRUE, 'system', 'system' );

--服务员管理
	
	INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	(26, 'menu', '查看', '服务员管理菜单-》查看操作', 25, TRUE, 'system', 'system' );
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	(27, 'menu', '添加服务员', '服务员管理菜单-》添加服务员操作', 26, TRUE, 'system', 'system' );
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	( 28,'menu', '编辑', '服务员管理菜单-》编辑操作', 27, TRUE, 'system', 'system' );
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	( 29,'menu', '启用/禁用', '服务员管理菜单-》启用/禁用操作', 28, TRUE, 'system', 'system' );
	INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	(30, 'menu', '承接项目', '服务员管理菜单-》承接项目操作', 29, TRUE, 'system', 'system' );
	
--所有任务

	INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	(31, 'menu', '查看', '所有任务菜单-》查看操作', 30, TRUE, 'system', 'system' );
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	( 32,'menu', '导出', '所有任务菜单-》导出操作', 31, TRUE, 'system', 'system' );
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	( 33,'menu', '受理', '所有任务菜单-》受理操作', 32, TRUE, 'system', 'system' );
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	(34, 'menu', '取消', '所有任务菜单-》取消操作', 33, TRUE, 'system', 'system' );
	INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	(35, 'menu', '退款', '所有任务菜单-》退款操作', 34, TRUE, 'system', 'system' );
	INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	(36, 'menu', '激活礼包', '所有任务菜单-》激活礼包操作', 35, TRUE, 'system', 'system' );

--我的任务

--角色管理（补充）
SELECT nextval ( 'permission_id_permission_seq' );
	
INSERT INTO permission (id_permission, permission_type, permission_name, permission_descr, resource_id, is_enabled, created_by, updated_by )
VALUES
	( 37,'menu', '查看角色详情用户列表', '角色管理菜单-》查看角色详情用户列表操作', 36, TRUE, 'system', 'system' );
	
	commit;