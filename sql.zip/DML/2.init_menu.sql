--menu表插入数据
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );
SELECT nextval ( 'menu_id_menu_seq' );


--一级菜单
INSERT INTO menu ( id_menu, menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	( 1, '01', '权限管理', '权限管理菜单', 'auth', '', 0, '0/', 'system', 'system' );
INSERT INTO menu ( id_menu,menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	(2, '01', '服务管理', '服务管理菜单', 'agence', '', 0, '0/', 'system', 'system' );	
	INSERT INTO menu (id_menu, menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	( 3,'01', '年检调度中心', '调度中心菜单', 'dispatch', '', 0, '0/', 'system', 'system' );
	
	
	
	
--二级菜单
INSERT INTO menu (id_menu, menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	( 4,'02', '用户管理', '用户管理菜单', 'auth:user:index', 'codsuser', 1, '0/1/', 'system', 'system' );
INSERT INTO menu ( id_menu,menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	( 5,'02', '角色管理', '角色管理菜单', 'auth:role:index', 'roleList', 1, '0/1/', 'system', 'system' );
	INSERT INTO menu ( id_menu,menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	( 6,'02', '服务商管理', '服务商管理菜单', 'agence:company:index', 'companyList', 2, '0/2/', 'system', 'system' );
INSERT INTO menu ( id_menu,menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	(7, '02', '服务员管理', '服务员管理菜单', 'agence:person:index', 'waiterList', 2, '0/2/', 'system', 'system' );
	
	INSERT INTO menu (id_menu, menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	( 8,'02', '所有任务', '所有任务菜单', 'dispatch:alltask:index', 'allTaskList', 3, '0/3/', 'system', 'system' );
INSERT INTO menu ( id_menu,menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	( 9,'02', '我的任务', '我的任务菜单', 'dispatch:mytask:index', 'myTaskList', 3, '0/3/', 'system', 'system' );
	
	
	
--三级菜单

	--用户管理操作
INSERT INTO menu (id_menu, menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	( 10,'03', '查看', '用户管理菜单-》查看操作', 'auth:user:view', '', 4, '0/1/4/', 'system', 'system' );
INSERT INTO menu (id_menu, menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	( 11,'03', '添加用户', '用户管理菜单-》添加用户操作', 'auth:user:add', '', 4, '0/1/4/', 'system', 'system' );
INSERT INTO menu ( id_menu,menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	( 12,'03', '编辑', '用户管理菜单-》编辑操作', 'auth:user:edit', '', 4, '0/1/4/', 'system', 'system' );
INSERT INTO menu (id_menu, menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	( 13,'03', '启用/禁用', '用户管理菜单-》启用/禁用操作', 'auth:user:change', '', 4, '0/1/4/', 'system', 'system' );
INSERT INTO menu ( id_menu,menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	( 14,'03', '机构用户', '用户管理菜单-》机构用户操作', 'auth:user:isdepartmentuser', '', 4, '0/1/4/', 'system', 'system' );
	
	--角色管理操作
INSERT INTO menu ( id_menu,menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	(15, '03', '查看', '角色管理菜单-》查看操作', 'auth:role:view', '', 5, '0/1/5/', 'system', 'system' );
INSERT INTO menu (id_menu, menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	(16, '03', '添加角色', '角色管理菜单-》添加角色操作', 'auth:role:add', '', 5, '0/1/5/', 'system', 'system' );
INSERT INTO menu (id_menu, menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	( 17,'03', '编辑', '角色管理菜单-》编辑操作', 'auth:role:edit', '', 5, '0/1/5/', 'system', 'system' );
INSERT INTO menu ( id_menu,menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	( 18,'03', '删除', '角色管理菜单-》删除操作', 'auth:role:delete', '', 5, '0/1/5/', 'system', 'system' );

	
	--服务商管理操作
INSERT INTO menu ( id_menu,menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	(19, '03', '查看', '服务商管理菜单-》查看操作', 'agence:company:view', '', 6, '0/1/6/', 'system', 'system' );
INSERT INTO menu (id_menu, menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	(20, '03', '添加服务商', '服务商管理菜单-》添加服务商操作', 'agence:company:add', '', 6, '0/1/6/', 'system', 'system' );
INSERT INTO menu (id_menu, menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	( 21,'03', '编辑', '服务商管理菜单-》编辑操作', 'agence:company:edit', '', 6, '0/1/6/', 'system', 'system' );
INSERT INTO menu ( id_menu,menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	( 22,'03', '启用/禁用', '服务商管理菜单-》启用/禁用操作', 'agence:company:change', '', 6, '0/1/6/', 'system', 'system' );	
INSERT INTO menu ( id_menu,menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	( 23,'03', '承接项目', '服务商管理菜单-》承接项目操作', 'agence:company:items', '', 6, '0/1/6/', 'system', 'system' );
INSERT INTO menu ( id_menu,menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	( 24,'03', '服务员列表', '服务商管理菜单-》服务员列表操作', 'agence:company:persons', '', 6, '0/1/6/', 'system', 'system' );	
	
	--服务员管理操作
	INSERT INTO menu ( id_menu,menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	(25, '03', '查看', '服务员管理菜单-》查看操作', 'agence:person:view', '', 7, '0/1/7/', 'system', 'system' );
INSERT INTO menu (id_menu, menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	(26, '03', '添加服务员', '服务员管理菜单-》添加服务员操作', 'agence:person:add', '', 7, '0/1/7/', 'system', 'system' );
INSERT INTO menu (id_menu, menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	(27,'03', '编辑', '服务员管理菜单-》编辑操作', 'agence:person:edit', '', 7, '0/1/7/', 'system', 'system' );
INSERT INTO menu ( id_menu,menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	( 28,'03', '启用/禁用', '服务员管理菜单-》启用/禁用操作', 'agence:person:change', '', 7, '0/1/7/', 'system', 'system' );	
INSERT INTO menu ( id_menu,menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	( 29,'03', '承接项目', '服务员管理菜单-》承接项目操作', 'agence:person:items', '', 7, '0/1/7/', 'system', 'system' );

	--所有任务操作
	INSERT INTO menu ( id_menu,menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	(30, '03', '查看', '所有任务菜单-》查看操作', 'dispatch:alltask:view', '', 8, '0/1/8/', 'system', 'system' );
INSERT INTO menu (id_menu, menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	(31, '03', '导出', '所有任务菜单-》导出操作', 'dispatch:alltask:export', '', 8, '0/1/8/', 'system', 'system' );
INSERT INTO menu (id_menu, menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	(32,'03', '受理', '所有任务菜单-》受理操作', 'dispatch:alltask:handle', '', 8, '0/1/8/', 'system', 'system' );
INSERT INTO menu ( id_menu,menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	(33,'03', '取消', '所有任务菜单-》取消操作', 'dispatch:alltask:cancel', '', 8, '0/1/8/', 'system', 'system' );	
INSERT INTO menu ( id_menu,menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	(34,'03', '退款', '所有任务菜单-》退款操作', 'dispatch:alltask:refund', '', 8, '0/1/8/', 'system', 'system' );
	INSERT INTO menu ( id_menu,menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	(35,'03', '激活礼包', '所有任务菜单-》激活礼包操作', 'dispatch:alltask:enablegiftbag', '', 8, '0/1/8/', 'system', 'system' );
	
	--我的任务操作
		
	--角色管理操作（补充）
SELECT nextval ( 'menu_id_menu_seq' );
INSERT INTO menu ( id_menu,menu_type, menu_name, menu_descr, menu_code, menu_url, parent_id, parent_ids, created_by, updated_by )
VALUES
	( 36,'03', '用户列表', '角色管理菜单-》用户列表角色详情页操作', 'auth:role:users', '', 5, '0/1/5/', 'system', 'system' );	
commit;

