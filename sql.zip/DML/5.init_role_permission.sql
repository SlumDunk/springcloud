--r_role_permission表插入数据
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 1, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 2, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 3, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 4, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 5, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 6, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 7, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 8, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 9, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 10, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 11, 'system', 'system' );
	
	INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 12, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 13, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 14, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 15, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 16, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 17, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 18, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 19, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 20, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 21, 'system', 'system' );
	
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 22, 'system', 'system' );
INSERT INTO r_role_permission (id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 23, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 24, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 25, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 26, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 27, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 28, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 29, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 30, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 31, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 32, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 33, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 34, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 35, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 36, 'system', 'system' );
INSERT INTO r_role_permission ( id_role, id_permission, created_by, updated_by )
VALUES
	( 1, 37, 'system', 'system' );
commit;