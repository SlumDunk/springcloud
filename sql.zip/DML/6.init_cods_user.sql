--c ods_user表插入数据 admin,zhangsan12345 
SELECT
	nextval ( 'cods_user_id_cods_user_seq' );
INSERT INTO cods_user ( id_cods_user, user_name, reg_phone, is_enabled, PASSWORD, salt, department_code, is_department_user, id_role, is_first_login, created_by, updated_by )
VALUES
	( 1, 'admin', '15521609185', TRUE, '941fec24654fb4bdae064718b14220c7cb1fe3a9f55a365c3ed2720e67a4f618', 'f4d35e33e4667ce9a88e8c59d279d26c', '001', TRUE, 1, FALSE, 'system', 'system' );
COMMIT;