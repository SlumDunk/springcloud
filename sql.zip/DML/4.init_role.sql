--role表插入数据
SELECT nextval ( 'role_id_role_seq' );

INSERT INTO ROLE (id_role, role_name, role_descr, is_enabled, created_by, updated_by )
VALUES
	(1, '超级管理员', '超级管理员用户', TRUE, 'system', 'system' );
	
	commit;