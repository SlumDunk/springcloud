/*==============================================================*/
/* DBMS name:      PostgreSQL 9.x                               */
/* Created on:     2018/3/19 16:28:44                           */
/*==============================================================*/


drop index if exists IDX_APP_USER_CREATED_DT;

drop index if exists IDX_APP_USER_REG_PHONE;

drop table if exists app_user;

drop index if exists IDX_COMPANY_CREATED_DT;

drop table if exists company;

drop table if exists r_department_city;

drop table if exists menu;

drop table if exists permission;

drop table if exists r_app_user_city;

drop table if exists r_app_user_company;

drop table if exists r_app_user_service_item;

drop table if exists r_company_city;

drop table if exists r_company_department;

drop table if exists r_company_service_item;

drop table if exists r_role_permission;

drop table if exists r_web_user_company;

drop table if exists role;

drop table if exists service_item;

drop index if exists IDX_SYS_LOG_OBJ_NAME;

drop index if exists IDX_SYS_LOG_OBJ_ID;

drop index if exists IDX_SYS_LOG_CREATED_DT;

drop table if exists sys_log;

drop index if exists IDX_USER_LOGIN_LOG_CELLPHONE;

drop index if exists IDX_USER_LOGIN_LOG_CREATED_DT;

drop table if exists user_login_log;

drop index if exists IDX_WEB_USER_REG_PHONE;

drop index if exists IDX_WEB_USER_CREATED_DT;

drop table if exists web_user;

/*==============================================================*/
/* Table: app_user                                              */
/*==============================================================*/
create table app_user (
   id_app_user          SERIAL 				 not null,
   user_name            VARCHAR(50)          not null,
   reg_phone            VARCHAR(20)          not null,
   is_enabled           BOOL                 not null,
   is_online            BOOL                 not null,
   is_accept_order      BOOL                 not null,
   id_company           INT4                 null,
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by           VARCHAR(50)          not null,
   updated_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_APP_USER primary key (id_app_user),
   constraint UK_APP_USER_REG_PHONE unique (reg_phone)
);

comment on table app_user is
'APP用户表';

comment on column app_user.id_app_user is
'主键ID';

comment on column app_user.user_name is
'用户名称';

comment on column app_user.reg_phone is
'用户注册手机';

comment on column app_user.is_enabled is
'是否启用(true:启用，false:不启用，默认为false)';

comment on column app_user.is_online is
'是否在线(true:在线，false:不在线，默认为true)';

comment on column app_user.is_accept_order is
'是否开启接单(true:启用，false:不启用，默认为false)';

comment on column app_user.id_company is
'直属服务商';

comment on column app_user.created_by is
'创建人';

comment on column app_user.created_date is
'创建时间';

comment on column app_user.updated_by is
'更新人';

comment on column app_user.updated_date is
'更新时间';

/*==============================================================*/
/* Index: IDX_APP_USER_REG_PHONE                                */
/*==============================================================*/
create unique index IDX_APP_USER_REG_PHONE on app_user using BTREE (
reg_phone
);

/*==============================================================*/
/* Index: IDX_APP_USER_CREATED_DT                               */
/*==============================================================*/
create index IDX_APP_USER_CREATED_DT on app_user using BTREE (
created_date
);


/*==============================================================*/
/* Table: company                                               */
/*==============================================================*/
create table company (
   id_company           SERIAL 				 not null,
   company_name         VARCHAR(50)          not null,
   company_type         VARCHAR(2)           not null,
   business_type   		VARCHAR(2)           not null,
   linkman_name      	VARCHAR(50)          null,
   linkman_tel       	VARCHAR(20)          null,
   support_tel       	VARCHAR(20)          null,
   is_designate      	BOOL                 null,
   detail_address       VARCHAR(200)         null,
   work_time        	VARCHAR(50)          null,
   city_code            VARCHAR(20)          null,
   store_photo_url      VARCHAR(200)         null,
   is_enabled           BOOL                 not null,
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by          VARCHAR(50)          not null,
   updated_date        TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_COMPANY primary key (id_company)
);

comment on table company is
'公司表';

comment on column company.id_company is
'主键ID';

comment on column company.company_name is
'公司名字';

comment on column company.company_type is
'公司类型（01:平安门店/服务点,02:检测站,03:其他）';

comment on column company.business_type is
'业务类型（01:年检代办）';

comment on column company.linkman_name is
'联系人名字';

comment on column company.linkman_tel is
'联系人电话';

comment on column company.support_tel is
'客服电话';

comment on column company.is_designate is
'是否指派服务商（true:是,false:否,默认是false）';

comment on column company.detail_address is
'详细地址';

comment on column company.work_time is
'营业时间';

comment on column company.city_code is
'门店地址所属区域编码';

comment on column company.store_photo_url is
'门店照片url';

comment on column company.is_enabled is
'是否启用(true:启用,false:不启用,默认是true)';

comment on column company.created_by is
'创建人';

comment on column company.created_date is
'创建时间';

comment on column company.updated_by is
'更新人';

comment on column company.updated_date is
'更新时间';

/*==============================================================*/
/* Index: IDX_COMPANY_CREATED_DT                                */
/*==============================================================*/
create index IDX_COMPANY_CREATED_DT on company using BTREE (
created_date
);


/*==============================================================*/
/* Table: r_department_city                                   */
/*==============================================================*/
create table r_department_city (
   id_r_department_city SERIAL 				 not null,
   department_code      VARCHAR(20)          not null,
   city_code            VARCHAR(20)          not null,
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by          VARCHAR(50)          not null,
   updated_date        TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_R_DEPARTMENT_CITY primary key (id_r_department_city)
);

comment on table r_department_city is
'机构和地区关联关系表';

comment on column r_department_city.id_r_department_city is
'主键ID';

comment on column r_department_city.department_code is
'机构编码';

comment on column r_department_city.city_code is
'地区编码';

comment on column r_department_city.created_by is
'创建人';

comment on column r_department_city.created_date is
'创建时间';

comment on column r_department_city.updated_by is
'更新人';

comment on column r_department_city.updated_date is
'更新时间';

/*==============================================================*/
/* Table: menu                                                  */
/*==============================================================*/
create table menu (
   id_menu              SERIAL 				 not null,
   menu_type        	VARCHAR(2)           not null,
   menu_name         	VARCHAR(50)          not null,
   menu_descr         	VARCHAR(200)         not null,
   menu_code			VARCHAR(100)		 not null,
   menu_url             VARCHAR(200)         not null,
   parent_id            INT4                 not null,
   parent_ids			VARCHAR(50)			 not null,
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by          VARCHAR(50)          not null,
   updated_date        TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_MENU primary key (id_menu)
);

comment on table menu is
'菜单资源';

comment on column menu.id_menu is
'主键ID';

comment on column menu.menu_type is
'菜单类型（01:一级菜单，02:二级菜单，03:操作）';

comment on column menu.menu_name is
'菜单名称';

comment on column menu.menu_descr is
'菜单描述';

comment on column menu.menu_code is
'菜单编码';

comment on column menu.menu_url is
'菜单url';

comment on column menu.parent_id is
'父级菜单id(一级菜单父资源ID为0)';

comment on column menu.parent_ids is
'父级菜单id串';

comment on column menu.created_by is
'创建人';

comment on column menu.created_date is
'创建时间';

comment on column menu.updated_by is
'更新人';

comment on column menu.updated_date is
'更新时间';

/*==============================================================*/
/* Table: permission                                            */
/*==============================================================*/
create table permission (
   id_permission        SERIAL not null,
   permission_type      VARCHAR(20)          not null,
   permission_name      VARCHAR(30)          not null,
   permission_descr     VARCHAR(200)         not null,
   resource_id          INT4                 not null,
   is_enabled           BOOL                 not null,
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by          VARCHAR(50)          not null,
   updated_date        TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_PERMISSION primary key (id_permission)
);

comment on table permission is
'权限表';

comment on column permission.id_permission is
'主键ID';

comment on column permission.permission_type is
'权限类型';

comment on column permission.permission_name is
'权限名称';

comment on column permission.permission_descr is
'权限描述';

comment on column permission.resource_id is
'资源ID';

comment on column permission.is_enabled is
'是否启用(true:启用，false:不启用，默认为true)';

comment on column permission.created_by is
'创建人';

comment on column permission.created_date is
'创建时间';

comment on column permission.updated_by is
'更新人';

comment on column permission.updated_date is
'更新时间';

/*==============================================================*/
/* Table: r_app_user_city                                       */
/*==============================================================*/
create table r_app_user_city (
   id_r_app_user_city   SERIAL 				 not null,
   id_app_user          INT4                 not null,
   city_code            VARCHAR(20)          not null,
   business_type   		VARCHAR(2)           not null,
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by          VARCHAR(50)          not null,
   updated_date        TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_R_APP_USER_CITY primary key (id_r_app_user_city),
   constraint UK_APP_USER_CITY unique (id_app_user, city_code)
);

comment on table r_app_user_city is
'app用户和服务地区关联关系表';

comment on column r_app_user_city.id_r_app_user_city is
'主键ID';

comment on column r_app_user_city.id_app_user is
'app用户ID';

comment on column r_app_user_city.city_code is
'服务地区编码';

comment on column r_app_user_city.business_type is
'业务类型编码(01:年检代办）';

comment on column r_app_user_city.created_by is
'创建人';

comment on column r_app_user_city.created_date is
'创建时间';

comment on column r_app_user_city.updated_by is
'更新人';

comment on column r_app_user_city.updated_date is
'更新时间';

/*==============================================================*/
/* Table: r_app_user_company                                    */
/*==============================================================*/
create table r_app_user_company (
   id_r_app_user_company SERIAL 			 not null,
   id_app_user          INT4                 not null,
   id_company           INT4                 not null,   
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by          VARCHAR(50)          not null,
   updated_date        TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_R_APP_USER_COMP primary key (id_r_app_user_company),
   constraint UK_APP_USER_COMP unique (id_app_user, id_company)
);

comment on table r_app_user_company is
'app用户跟检测站关联关系表';

comment on column r_app_user_company.id_r_app_user_company is
'主键ID';

comment on column r_app_user_company.id_app_user is
'app用户ID';

comment on column r_app_user_company.id_company is
'服务公司ID';

comment on column r_app_user_company.created_by is
'创建人';

comment on column r_app_user_company.created_date is
'创建时间';

comment on column r_app_user_company.updated_by is
'更新人';

comment on column r_app_user_company.updated_date is
'更新时间';

/*==============================================================*/
/* Table: r_app_user_service_item                               */
/*==============================================================*/
create table r_app_user_service_item (
   id_r_app_user_service_item SERIAL 		 not null,
   id_app_user          INT4                 not null,
   id_service_item      INT4                 not null,
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by        	VARCHAR(50)          not null,
   updated_date        TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_R_APP_USER_SERVICE_ITEM primary key (id_r_app_user_service_item),
   constraint UK_APP_USER_SERVICE_ITEM unique (id_app_user, id_service_item)
);

comment on table r_app_user_service_item is
'app用户和所服务项目关联关系表';

comment on column r_app_user_service_item.id_r_app_user_service_item is
'主键ID';

comment on column r_app_user_service_item.id_app_user is
'app用户ID';

comment on column r_app_user_service_item.id_service_item is
'服务项目ID';

comment on column r_app_user_service_item.created_by is
'创建人';

comment on column r_app_user_service_item.created_date is
'创建时间';

comment on column r_app_user_service_item.updated_by is
'更新人';

comment on column r_app_user_service_item.updated_date is
'更新时间';

/*==============================================================*/
/* Table: r_company_city                                        */
/*==============================================================*/
create table r_company_city (
   id_r_company_city    SERIAL 				 not null,
   id_company           INT4                 not null,
   city_code            VARCHAR(20)          not null,   
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by          VARCHAR(50)          not null,
   updated_date        TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_R_COMP_CITY primary key (id_r_company_city),
   constraint UK_COMP_CITY unique (id_company, city_code)
);

comment on table r_company_city is
'公司和服务地区关联关系表';

comment on column r_company_city.id_r_company_city is
'主键ID';

comment on column r_company_city.id_company is
'公司ID';

comment on column r_company_city.city_code is
'服务地区编码';

comment on column r_company_city.created_by is
'创建人';

comment on column r_company_city.created_date is
'创建时间';

comment on column r_company_city.updated_by is
'更新人';

comment on column r_company_city.updated_date is
'更新时间';

/*==============================================================*/
/* Table: r_company_department                                  */
/*==============================================================*/
create table r_company_department (
   id_r_company_department SERIAL 			 not null,
   department_code      VARCHAR(20)          not null,
   id_company           INT4                 not null,   
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by          VARCHAR(50)          not null,
   updated_date        TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_R_DEPART_COMP primary key (id_r_company_department),
   constraint UK_DEPART_COMP unique (department_code, id_company)
);

comment on table r_company_department is
'公司和机构关联关系表';

comment on column r_company_department.id_r_company_department is
'主键ID';

comment on column r_company_department.department_code is
'机构编码';

comment on column r_company_department.id_company is
'公司ID';

comment on column r_company_department.created_by is
'创建人';

comment on column r_company_department.created_date is
'创建时间';

comment on column r_company_department.updated_by is
'更新人';

comment on column r_company_department.updated_date is
'更新时间';

/*==============================================================*/
/* Table: r_company_service_item                                */
/*==============================================================*/
create table r_company_service_item (
   id_r_company_service_item SERIAL 		 not null,
   id_company           INT4                 not null,
   id_service_item      INT4                 not null,
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by          VARCHAR(50)          not null,
   updated_date        TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_R_COMP_SERVICE_ITEM primary key (id_r_company_service_item),
   constraint UK_COMP_SERVICE unique (id_company, id_service_item)
);

comment on table r_company_service_item is
'公司和服务项目详细关联关系表';

comment on column r_company_service_item.id_r_company_service_item is
'主键ID';

comment on column r_company_service_item.id_company is
'公司ID';

comment on column r_company_service_item.id_service_item is
'服务项目ID';

comment on column r_company_service_item.created_by is
'创建人';

comment on column r_company_service_item.created_date is
'创建时间';

comment on column r_company_service_item.updated_by is
'更新人';

comment on column r_company_service_item.updated_date is
'更新时间';

/*==============================================================*/
/* Table: r_role_permission                                     */
/*==============================================================*/
create table r_role_permission (
   id_r_role_permission SERIAL 				 not null,
   id_role              INT4                 not null,
   id_permission        INT4                 not null,
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by          VARCHAR(50)          not null,
   updated_date        TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_R_ROLE_PERMISSION primary key (id_r_role_permission),
   constraint UK_ROLE_PERMISSION unique (id_role, id_permission)
);

comment on table r_role_permission is
'角色-权限操作关联关系表';

comment on column r_role_permission.id_r_role_permission is
'主键ID';

comment on column r_role_permission.id_role is
'角色ID';

comment on column r_role_permission.id_permission is
'权限ID';

comment on column r_role_permission.created_by is
'创建人';

comment on column r_role_permission.created_date is
'创建时间';

comment on column r_role_permission.updated_by is
'更新人';

comment on column r_role_permission.updated_date is
'更新时间';

/*==============================================================*/
/* Table: r_web_user_company                                    */
/*==============================================================*/
create table r_web_user_company (
   id_r_web_user_company SERIAL 			 not null,
   id_web_user          INT4                 not null,
   id_company           INT4                 not null,   
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by          VARCHAR(50)          not null,
   updated_date        TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_R_WEB_USER_COMP primary key (id_r_web_user_company),
   constraint UK_WEB_USER_COMP unique (id_web_user, id_company)
);

comment on table r_web_user_company is
'用户和所服务公司关联关系表';

comment on column r_web_user_company.id_r_web_user_company is
'主键ID';

comment on column r_web_user_company.id_web_user is
'web平台用户ID';

comment on column r_web_user_company.id_company is
'所服务公司ID';


comment on column r_web_user_company.created_by is
'创建人';

comment on column r_web_user_company.created_date is
'创建时间';

comment on column r_web_user_company.updated_by is
'更新人';

comment on column r_web_user_company.updated_date is
'更新时间';

/*==============================================================*/
/* Table: role                                                  */
/*==============================================================*/
create table role (
   id_role              SERIAL 				 not null,
   role_name            VARCHAR(50)          not null,
   role_descr           VARCHAR(200)         not null,
   is_enabled           BOOL                 not null,
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by          VARCHAR(50)          not null,
   updated_date        TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_ROLE primary key (id_role)
);

comment on table role is
'角色表';

comment on column role.id_role is
'主键ID';

comment on column role.role_name is
'角色名称';

comment on column role.role_descr is
'角色描述';

comment on column role.is_enabled is
'是否启用（true:启用，false:不启用，默认为true）';

comment on column role.created_by is
'创建人';

comment on column role.created_date is
'创建时间';

comment on column role.updated_by is
'更新人';

comment on column role.updated_date is
'更新时间';

/*==============================================================*/
/* Table: service_item                                          */
/*==============================================================*/
create table service_item (
   id_service_item      SERIAL 				 not null,
   service_name         VARCHAR(50)          not null,
   service_code         VARCHAR(2)           not null,
   service_type         VARCHAR(2)           not null,
   business_type   		VARCHAR(2)           not null,
   parent_id            INT4                 not null,
   is_enabled           BOOL                 not null,
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by          VARCHAR(50)          not null,
   updated_date        TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_SERVICE_ITEM primary key (id_service_item)
);

comment on table service_item is
'服务项目资源表';

comment on column service_item.id_service_item is
'主键ID';

comment on column service_item.service_name is
'服务项目名称';

comment on column service_item.service_code is
'服务项目代码';

comment on column service_item.service_type is
'项目类型(01:一级服务项目，02:二级服务项目)';

comment on column service_item.business_type is
'业务类型编码（01:年检代办）';

comment on column service_item.parent_id is
'父级服务项目ID（顶级服务项目父ID为0）';

comment on column service_item.is_enabled is
'是否启用(true:启用，false:不启用，默认为true)';

comment on column service_item.created_by is
'创建人';

comment on column service_item.created_date is
'创建时间';

comment on column service_item.updated_by is
'更新人';

comment on column service_item.updated_date is
'更新时间';

/*==============================================================*/
/* Table: sys_log                                               */
/*==============================================================*/
create table sys_log (
   id_sys_log           SERIAL 				 not null,
   log_type             VARCHAR(20)          not null,
   log_event_name       VARCHAR(20)          not null,
   log_content          VARCHAR(1000)        not null,
   log_obj_name         VARCHAR(200)         not null,
   log_obj_id           INT4                 not null,
   log_operator_id      INT4                 not null,
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by          VARCHAR(50)          not null,
   updated_date        TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_SYS_LOG primary key (id_sys_log)
);

comment on table sys_log is
'系统操作日志记录表';

comment on column sys_log.id_sys_log is
'主键ID';

comment on column sys_log.log_type is
'日志类型';

comment on column sys_log.log_event_name is
'日志事件名称';

comment on column sys_log.log_content is
'日志内容';

comment on column sys_log.log_obj_name is
'日志对象名称';

comment on column sys_log.log_obj_id is
'日志对象标志';

comment on column sys_log.log_operator_id is
'日志操作人ID';

comment on column sys_log.created_by is
'创建人';

comment on column sys_log.created_date is
'创建时间';

comment on column sys_log.updated_by is
'更新人';

comment on column sys_log.updated_date is
'更新时间';

/*==============================================================*/
/* Index: IDX_SYS_LOG_CREATED_DT                                */
/*==============================================================*/
create index IDX_SYS_LOG_CREATED_DT on sys_log using BTREE (
created_date
);

/*==============================================================*/
/* Index: IDX_SYS_LOG_OBJ_ID                                    */
/*==============================================================*/
create index IDX_SYS_LOG_OBJ_ID on sys_log using BTREE (
log_obj_id
);

/*==============================================================*/
/* Index: IDX_SYS_LOG_OBJ_NAME                                  */
/*==============================================================*/
create index IDX_SYS_LOG_OBJ_NAME on sys_log using BTREE (
log_obj_name
);

/*==============================================================*/
/* Table: user_login_log                                        */
/*==============================================================*/
create table user_login_log (
   id_user_login_log    SERIAL 				 not null,
   id_user              INT4                 not null,
   user_type            VARCHAR(5)           not null,
   login_time           TIMESTAMP            not null,
   login_ip             VARCHAR(64)          not null,
   cellphone            VARCHAR(20)          not null,
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by          VARCHAR(50)          not null,
   updated_date        TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_USER_LOGIN_LOG primary key (id_user_login_log)
);

comment on table user_login_log is
'用户登录日志表';

comment on column user_login_log.id_user_login_log is
'主键ID';

comment on column user_login_log.id_user is
'用户ID';

comment on column user_login_log.user_type is
'用户类型(WEB:web用户,APP:app用户)';

comment on column user_login_log.login_time is
'登录时间';

comment on column user_login_log.login_ip is
'登录IP';

comment on column user_login_log.cellphone is
'登录手机号';

comment on column user_login_log.created_by is
'创建人';

comment on column user_login_log.created_date is
'创建时间';

comment on column user_login_log.updated_by is
'更新人';

comment on column user_login_log.updated_date is
'更新时间';

/*==============================================================*/
/* Index: IDX_USER_LOGIN_LOG_CREATED_DT                         */
/*==============================================================*/
create  index IDX_USER_LOGIN_LOG_CREATED_DT on user_login_log using BTREE (
created_date
);

/*==============================================================*/
/* Index: IDX_USER_LOGIN_LOG_CELLPHONE                          */
/*==============================================================*/
create index IDX_USER_LOGIN_LOG_CELLPHONE on user_login_log using BTREE (
cellphone
);

/*==============================================================*/
/* Table: web_user                                              */
/*==============================================================*/
create table web_user (
   id_web_user          SERIAL 				 not null,
   user_name            VARCHAR(50)          not null,
   reg_phone            VARCHAR(20)          not null,
   is_enabled           BOOL                 not null,
   password             VARCHAR(64)          not null,
   salt					VARCHAR(32)			 not null,
   department_code      VARCHAR(20)          null,
   is_department_user	BOOL				 not null,
   id_role              INT4                 not null,
   is_first_login       BOOL                 not null,
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by          VARCHAR(50)          not null,
   updated_date        TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_WEB_USER primary key (id_web_user),
   constraint UK_WEB_USER_REG_PHONE unique (reg_phone)
);

comment on table web_user is
'平台WEB登录用户表';

comment on column web_user.id_web_user is
'主键ID';

comment on column web_user.user_name is
'用户名称';

comment on column web_user.reg_phone is
'用户注册手机';

comment on column web_user.is_enabled is
'是否启用(true:启用，false:不启用，默认为true)';

comment on column web_user.password is
'登录密码';

comment on column web_user.salt is
'密码盐值';

comment on column web_user.department_code is
'用户所属机构编码';

comment on column web_user.is_department_user is
'是否机构人员(true:是,false:否,默认为true)';

comment on column web_user.id_role is
'角色ID';

comment on column web_user.is_first_login is
'是否第一次登录(true:是,false:否,默认为true)';

comment on column web_user.created_by is
'创建人';

comment on column web_user.created_date is
'创建时间';

comment on column web_user.updated_by is
'更新人';

comment on column web_user.updated_date is
'更新时间';

/*==============================================================*/
/* Index: IDX_WEB_USER_CREATED_DT                               */
/*==============================================================*/
create index IDX_WEB_USER_CREATED_DT on web_user using BTREE (
created_date
);

/*==============================================================*/
/* Index: IDX_WEB_USER_REG_PHONE                                */
/*==============================================================*/
create unique index IDX_WEB_USER_REG_PHONE on web_user using BTREE (
reg_phone
);

grant all on app_user to codsopr;

grant all on company to codsopr;

grant all on menu to codsopr;

grant all on permission to codsopr;

grant all on r_app_user_city to codsopr;

grant all on r_app_user_company to codsopr;

grant all on r_app_user_service_item to codsopr;

grant all on r_company_city to codsopr;

grant all on r_company_department to codsopr;

grant all on r_company_service_item to codsopr;

grant all on r_department_city to codsopr;

grant all on r_role_permission to codsopr;

grant all on r_web_user_company to codsopr;

grant all on role to codsopr;

grant all on service_item to codsopr;

grant all on sys_log to codsopr;

grant all on user_login_log to codsopr;

grant all on web_user to codsopr;