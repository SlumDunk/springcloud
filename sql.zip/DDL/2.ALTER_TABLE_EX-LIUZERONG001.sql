drop index if exists IDX_APP_USER_CREATED_DT;

drop index if exists IDX_APP_USER_REG_PHONE;

drop table if exists app_user;

drop table if exists service_man;

drop table if exists r_app_user_city;

drop table if exists r_app_user_company;

drop table if exists r_app_user_service_item;

drop table if exists r_service_man_city;

drop table if exists r_service_man_company;

drop table if exists r_service_man_service_item;

drop index if exists IDX_COMPANY_CREATED_DT;

drop index if exists IDX_COMPANY_CODE;

drop index if exists IDX_COMPANY_DETAIL_CREATED_DT;

drop table if exists company;

drop table if exists company_detail;

drop table if exists r_company_city;

/* web_user表调整 */
drop index if exists IDX_WEB_USER_REG_PHONE;

drop index if exists IDX_WEB_USER_CREATED_DT;

drop table if exists web_user;

drop table if exists r_web_user_company;

drop index if exists IDX_USER_REG_PHONE;

drop index if exists IDX_USER_CREATED_DT;

drop table if exists cods_user;

drop table if exists r_cods_user_company;



/*==============================================================*/
/* Table: service_man   服务员表                                */
/*==============================================================*/
create table service_man (
   id_service_man          SERIAL 				 not null,
   service_man_name     VARCHAR(50)          not null,
   reg_phone            VARCHAR(20)          not null,
   id_company         	INT4          		 not null,
   is_online            BOOL                 not null,
   is_accept_order      BOOL                 not null,
   average_score		NUMERIC(2,1)		 not null default 0,
   order_amount			INT4				 not null default 0,
   processing_order		INT4				 not null default 0,
   profile_photo_url	VARCHAR(200)		 null,
   is_enabled           BOOL                 not null,
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by           VARCHAR(50)          not null,
   updated_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_SERVICE_MAN primary key (id_service_man),
   constraint UK_SERVICE_MAN_REG_PHONE unique (reg_phone)
);

comment on table service_man is
'服务员表';

comment on column service_man.id_service_man is
'主键ID';

comment on column service_man.service_man_name is
'服务员名称';

comment on column service_man.reg_phone is
'服务员注册手机';

comment on column service_man.id_company is
'直属服务商ID';

comment on column service_man.is_online is
'是否在线(true:在线，false:不在线，默认为false)';

comment on column service_man.is_accept_order is
'是否开启接单(true:启用，false:不启用，默认为false)';

comment on column service_man.average_score is
'平均分数(默认为0)';

comment on column service_man.order_amount is
'总接单量(默认为0)';

comment on column service_man.processing_order is
'当前接单量(默认为0)';

comment on column service_man.profile_photo_url is
'头像url';

comment on column service_man.is_enabled is
'是否启用(true:启用，false:不启用，默认为true)';

comment on column service_man.created_by is
'创建人';

comment on column service_man.created_date is
'创建时间';

comment on column service_man.updated_by is
'更新人';

comment on column service_man.updated_date is
'更新时间';

/*==============================================================*/
/* Index: IDX_SERVICE_MAN_REG_PHONE                                */
/*==============================================================*/
create unique index IDX_SERVICE_MAN_REG_PHONE on service_man using BTREE (
reg_phone
);

/*==============================================================*/
/* Index: IDX_SERVICE_MAN_CREATED_DT                               */
/*==============================================================*/
create index IDX_SERVICE_MAN_CREATED_DT on service_man using BTREE (
created_date
);


/*==============================================================*/
/* Table: r_service_man_city 服务员服务地区关联关系表           */
/*==============================================================*/
create table r_service_man_city (
   id_r_service_man_city   SERIAL 				 not null,
   id_service_man          INT4                 not null,
   city_code            VARCHAR(20)          not null,
   business_type   		VARCHAR(2)           not null,
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by          VARCHAR(50)          not null,
   updated_date        TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_R_SERVICE_MAN_CITY primary key (id_r_service_man_city),
   constraint UK_SERVICE_MAN_CITY unique (id_service_man, city_code)
);

comment on table r_service_man_city is
'服务员和服务地区关联关系表';

comment on column r_service_man_city.id_r_service_man_city is
'主键ID';

comment on column r_service_man_city.id_service_man is
'服务员ID';

comment on column r_service_man_city.city_code is
'服务地区编码';

comment on column r_service_man_city.business_type is
'业务类型编码(01:年检代办)';

comment on column r_service_man_city.created_by is
'创建人';

comment on column r_service_man_city.created_date is
'创建时间';

comment on column r_service_man_city.updated_by is
'更新人';

comment on column r_service_man_city.updated_date is
'更新时间';

/*==============================================================*/
/* Table: r_service_man_company  服务员和间接关联服务商关联关系表*/
/*==============================================================*/
create table r_service_man_company (
   id_r_service_man_company SERIAL 			 not null,
   id_service_man          INT4                 not null,
   id_company           INT4                 not null,   
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by          VARCHAR(50)          not null,
   updated_date        TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_R_SERVICE_MAN_COMP primary key (id_r_service_man_company),
   constraint UK_SERVICE_MAN_COMP unique (id_service_man, id_company)
);

comment on table r_service_man_company is
'服务员跟检测站关联关系表';

comment on column r_service_man_company.id_r_service_man_company is
'主键ID';

comment on column r_service_man_company.id_service_man is
'服务员ID';

comment on column r_service_man_company.id_company is
'服务公司ID';

comment on column r_service_man_company.created_by is
'创建人';

comment on column r_service_man_company.created_date is
'创建时间';

comment on column r_service_man_company.updated_by is
'更新人';

comment on column r_service_man_company.updated_date is
'更新时间';

/*==============================================================*/
/* Table: r_service_man_service_item  服务员和服务项目关联关系表*/
/*==============================================================*/
create table r_service_man_service_item (
   id_r_service_man_service_item SERIAL 		 not null,
   id_service_man          INT4                 not null,
   id_service_item      INT4                 not null,
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by        	VARCHAR(50)          not null,
   updated_date        TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_R_SERVICE_MAN_SERVICE_ITEM primary key (id_r_service_man_service_item),
   constraint UK_SERVICE_MAN_SERVICE_ITEM unique (id_service_man, id_service_item)
);

comment on table r_service_man_service_item is
'服务员和服务项目关联关系表';

comment on column r_service_man_service_item.id_r_service_man_service_item is
'主键ID';

comment on column r_service_man_service_item.id_service_man is
'服务员ID';

comment on column r_service_man_service_item.id_service_item is
'服务项目ID';

comment on column r_service_man_service_item.created_by is
'创建人';

comment on column r_service_man_service_item.created_date is
'创建时间';

comment on column r_service_man_service_item.updated_by is
'更新人';

comment on column r_service_man_service_item.updated_date is
'更新时间';

/*用户登录日志表备注修改 */
comment on column user_login_log.user_type is
'用户类型(CODS:系统用户,SERVICEMAN:服务员用户)';

/*==============================================================*/
/* Table: company 服务商表                        	    		*/
/*==============================================================*/
create table company (
   id_company           SERIAL 				 not null,
   company_name         VARCHAR(50)          not null,
   company_type         VARCHAR(2)           not null,
   detail_address       VARCHAR(200)         null,
   work_time        	VARCHAR(50)          null,
   city_code            VARCHAR(20)          null,
   store_photo_url      VARCHAR(200)         null,
   is_enabled           BOOL                 not null,
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by           VARCHAR(50)          not null,
   updated_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_COMPANY primary key (id_company)
);

comment on table company is
'公司表';

comment on column company.id_company is
'主键ID';

comment on column company.company_name is
'公司名字';

comment on column company.company_type is
'公司类型(01:平安门店/服务点,02:检测站,03:其他)';

comment on column company.detail_address is
'详细地址';

comment on column company.work_time is
'营业时间';

comment on column company.city_code is
'门店地址所属地区编码';

comment on column company.store_photo_url is
'门店照片url';

comment on column company.is_enabled is
'是否启用(true:启用,false:不启用,默认是true)';

comment on column company.created_by is
'创建人';

comment on column company.created_date is
'创建时间';

comment on column company.updated_by is
'更新人';

comment on column company.updated_date is
'更新时间';

/*==============================================================*/
/* Index: IDX_COMPANY_CREATED_DT                                */
/*==============================================================*/
create index IDX_COMPANY_CREATED_DT on company using BTREE (
created_date
);

/*==============================================================*/
/* Table: company_detail 服务商详情表             	            */
/*==============================================================*/
create table company_detail (
   id_company_detail	SERIAL				 not null,
   id_company           INT4                 not null,
   business_type   		VARCHAR(2)           not null,
   linkman_name      	VARCHAR(50)          null,
   linkman_tel       	VARCHAR(20)          null,
   support_tel       	VARCHAR(20)          null,
   is_designate      	BOOL                 null,
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by           VARCHAR(50)          not null,
   updated_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_COMPANY_DETAIL primary key (id_company_detail)
);

comment on table company_detail is
'服务商详情表';

comment on column company_detail.id_company_detail is
'主键ID';

comment on column company_detail.id_company is
'服务商ID';

comment on column company_detail.business_type is
'业务类型(01:年检代办)';

comment on column company_detail.linkman_name is
'联系人名字';

comment on column company_detail.linkman_tel is
'联系人电话';

comment on column company_detail.support_tel is
'客服电话';

comment on column company_detail.is_designate is
'是否指派服务商(true:是,false:否)';

comment on column company_detail.created_by is
'创建人';

comment on column company_detail.created_date is
'创建时间';

comment on column company_detail.updated_by is
'更新人';

comment on column company_detail.updated_date is
'更新时间';

/*==============================================================*/
/* Index: IDX_COMPANY_DETAIL_CREATED_DT                         */
/*==============================================================*/
create index IDX_COMPANY_DETAIL_CREATED_DT on company_detail using BTREE (
created_date
);

/*==============================================================*/
/* Table: r_company_city 服务商和服务地区关联关系表             */
/*==============================================================*/
create table r_company_city (
   id_r_company_city    SERIAL 				 not null,
   id_company           INT4                 not null,
   city_code            VARCHAR(20)          not null,
   business_type   		VARCHAR(2)           not null,
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by          VARCHAR(50)          not null,
   updated_date        TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_R_COMP_CITY primary key (id_r_company_city),
   constraint UK_COMP_CITY unique (id_company, city_code)
);

comment on table r_company_city is
'公司和服务地区关联关系表';

comment on column r_company_city.id_r_company_city is
'主键ID';

comment on column r_company_city.id_company is
'公司ID';

comment on column r_company_city.city_code is
'服务地区编码';

comment on column r_company_city.business_type is
'业务类型(01:年检代办)';

comment on column r_company_city.created_by is
'创建人';

comment on column r_company_city.created_date is
'创建时间';

comment on column r_company_city.updated_by is
'更新人';

comment on column r_company_city.updated_date is
'更新时间';

/*==============================================================*/
/* Table: r_cods_user_company 服务商和用户关联关系表            */
/*==============================================================*/
create table r_cods_user_company (
   id_r_cods_user_company SERIAL 			 not null,
   id_cods_user          INT4                 not null,
   id_company           INT4                 not null,
   business_type   		VARCHAR(2)           not null,
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by          VARCHAR(50)          not null,
   updated_date        TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_R_CODS_USER_COMP primary key (id_r_cods_user_company),
   constraint UK_CODS_USER_COMP unique (id_cods_user, id_company)
);

comment on table r_cods_user_company is
'用户和所服务公司关联关系表';

comment on column r_cods_user_company.id_r_cods_user_company is
'主键ID';

comment on column r_cods_user_company.id_cods_user is
'web平台用户ID';

comment on column r_cods_user_company.id_company is
'服务公司ID';

comment on column r_cods_user_company.business_type is
'业务类型(01:年检代办)';

comment on column r_cods_user_company.created_by is
'创建人';

comment on column r_cods_user_company.created_date is
'创建时间';

comment on column r_cods_user_company.updated_by is
'更新人';

comment on column r_cods_user_company.updated_date is
'更新时间';

/*==============================================================*/
/* Table: cods_user   系统用户表                                */
/*==============================================================*/
create table cods_user (
   id_cods_user          SERIAL 				 not null,
   user_name            VARCHAR(50)          not null,
   reg_phone            VARCHAR(20)          not null,
   is_enabled           BOOL                 not null,
   password             VARCHAR(64)          not null,
   salt					VARCHAR(32)			 not null,
   department_code      VARCHAR(20)          null,
   is_department_user	BOOL				 not null,
   id_role              INT4                 not null,
   is_first_login       BOOL                 not null,
   created_by           VARCHAR(50)          not null,
   created_date         TIMESTAMP            not null default CURRENT_TIMESTAMP,
   updated_by          VARCHAR(50)          not null,
   updated_date        TIMESTAMP            not null default CURRENT_TIMESTAMP,
   constraint PK_CODS_USER primary key (id_cods_user),
   constraint UK_CODS_USER_REG_PHONE unique (reg_phone)
);

comment on table cods_user is
'平台登录用户表';

comment on column cods_user.id_cods_user is
'主键ID';

comment on column cods_user.user_name is
'用户名称';

comment on column cods_user.reg_phone is
'用户注册手机';

comment on column cods_user.is_enabled is
'是否启用(true:启用，false:不启用，默认为true)';

comment on column cods_user.password is
'登录密码';

comment on column cods_user.salt is
'密码盐值';

comment on column cods_user.department_code is
'用户所属机构编码';

comment on column cods_user.is_department_user is
'是否机构人员(true:是,false:否,默认为true)';

comment on column cods_user.id_role is
'角色ID';

comment on column cods_user.is_first_login is
'是否第一次登录(true:是,false:否,默认为true)';

comment on column cods_user.created_by is
'创建人';

comment on column cods_user.created_date is
'创建时间';

comment on column cods_user.updated_by is
'更新人';

comment on column cods_user.updated_date is
'更新时间';

/*==============================================================*/
/* Index: IDX_CODS_USER_CREATED_DT                               */
/*==============================================================*/
create index IDX_CODS_USER_CREATED_DT on cods_user using BTREE (
created_date
);

/*==============================================================*/
/* Index: IDX_CODS_USER_REG_PHONE                                */
/*==============================================================*/
create unique index IDX_CODS_USER_REG_PHONE on cods_user using BTREE (
reg_phone
);
grant all on service_man to codsopr;

grant all on r_service_man_city to codsopr;

grant all on r_service_man_company to codsopr;

grant all on r_service_man_service_item to codsopr;

grant all on company to codsopr;

grant all on company_detail to codsopr;

grant all on r_company_city to codsopr;

grant all on r_cods_user_company to codsopr;

grant all on cods_user to codsopr;
