package com.tomcat.test;

import java.util.Map;
import java.util.Set;

public class ServletResourceProcessor {

    public void process(HttpRequest request,HttpResponse response){
        try {
            String uri = request.getUri();
            if(uri.contains("?")) {
                uri = uri.substring(0,uri.indexOf("?"));
            }
            XMLUntils.readXMLDemo();
            Set<Map.Entry<String,String>> setvletMappingentries =XMLUntils.servletMappingMap.entrySet();
            String className = "";
            for (Map.Entry<String,String> entry:setvletMappingentries){
                if(entry.getValue().equals(uri)){
                    className = XMLUntils.servletMap.get(entry.getKey());
                    System.out.println("className is"+className);
                    break;
                }
            }
            if(null != className && !("").equals(className)){
                HttpServlet servlet =(HttpServlet) Class.forName(className).newInstance();
                servlet.service(request,response);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}