package com.tomcat.test;

import java.io.IOException;

public class LoginServlet extends HttpServlet {

    public void service(HttpRequest request, HttpResponse response) throws IOException {
        String username = (String) request.getParamter("username");
        String password = (String) request.getParamter("password");
        if(("admin").equals(username) && ("admin123").equals(password)){
            response.writeFile("/webapp/loginSuccess.html");
        }else {
            response.writeFile("/webapp/loginFailed.html");
        }
    }
}
