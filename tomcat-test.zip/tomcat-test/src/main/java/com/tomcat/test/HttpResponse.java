package com.tomcat.test;

import java.io.*;

/**
 * 将响应内容返回给客户端
 */
public class HttpResponse {
    private OutputStream outputStream;
    private static final String fileContextPath=System.getProperty("user.dir")+"/src/main";
    public HttpResponse(OutputStream outputStream) {
        this.outputStream = outputStream;
    }
    public void writeFile(String path){
        try {
            FileInputStream fileInputStream = new FileInputStream(fileContextPath+path);
            byte[] buff = new byte[1024];
            int len = 0;
            while ((len = fileInputStream.read(buff))>-1){
                outputStream.write(buff,0,len);
            }
        }catch (FileNotFoundException e){
            e.printStackTrace();
            try {
                outputStream.write(new String("<html><body>404</body></html>").getBytes());
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }catch (Exception e){
            e.printStackTrace();
            try {
                outputStream.write(new String(e.getMessage()).getBytes());
            } catch (IOException e1) {
                e1.printStackTrace();
            }
        }finally {
            try {
                outputStream.flush();
                outputStream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

}
