package com.tomcat.test;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class XMLUntils {
    public static final Map<String,String> servletMap = new HashMap<String, String>();
    public static final Map<String,String> servletMappingMap = new HashMap<String, String>();
    public static void readXMLDemo() throws Exception {

        // 创建saxReader对象
        SAXReader reader = new SAXReader();
        // 通过read方法读取一个文件 转换成Document对象
        Document document = reader.read(new File("src/main/webapp/WEB-INF/web.xml"));
        //获取根节点元素对象
        Element node = document.getRootElement();
        elementMethod(node);

    }

    public static void elementMethod(Element node) {
        // 获取node节点中，子节点的元素名称为servlet的元素节点。
        List<Element> servletElements = node.elements("servlet");
        List<Element> servletMappingElements = node.elements("servlet-mapping");
        for (Element e : servletElements) {
            Element servletNameE = e.element("servlet-name");
            Element servletClassE = e.element("servlet-class");
            System.out.println(servletNameE.getText() + "----" +servletClassE.getText());
            servletMap.put(servletNameE.getText(),servletClassE.getText());
        }
        for (Element e : servletMappingElements) {
            Element servletNameE = e.element("servlet-name");
            Element urlPatternE = e.element("url-pattern");
            System.out.println(servletNameE.getText() + "----" +urlPatternE.getText());
            servletMappingMap.put(servletNameE.getText(),urlPatternE.getText());
        }
    }

    public static void main(String[] args) throws Exception {
        XMLUntils.readXMLDemo();
    }
}
