package com.tomcat.test;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class ThreadHandler implements Runnable {
    private Socket socket;

    public ThreadHandler(Socket socket) {
        this.socket = socket;
    }

    public void run() {
        try {
            if (null != socket) {
                InputStream inputStream = socket.getInputStream();
                OutputStream outputStream = socket.getOutputStream();
                HttpRequest request = new HttpRequest(inputStream);
                HttpResponse response = new HttpResponse(outputStream);
                //判断是否是servlet请求
                if(request.getUri().startsWith("/servlet")){
                    ServletResourceProcessor servletResourceProcessor = new ServletResourceProcessor();
                    servletResourceProcessor.process(request,response);
                }else{//静态资源
                    StaticResourceProcessor staticResourceProcessor = new StaticResourceProcessor();
                    staticResourceProcessor.process(request,response);
                }
                outputStream.close();
                inputStream.close();
                socket.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
