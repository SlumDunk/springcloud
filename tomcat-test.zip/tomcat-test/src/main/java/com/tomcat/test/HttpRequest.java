package com.tomcat.test;


import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * 解析客户端的请求(获取uri 请求method 请求参数)
 */
public class HttpRequest {
    private String uri;
    private String method;
    private Map<String, Object> paramMap = new HashMap<String, Object>();

    public HttpRequest(InputStream inputStream) throws IOException {
        init(inputStream);
    }

    private void init(InputStream inputStream) throws IOException {
        StringBuffer buffer = new StringBuffer();
        /*BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        String line = null;
        int i=0;
        while ((line = reader.readLine()) != null){
            if(i != 0){
                buffer.append("\r\n");
            }
            buffer.append(line);
            i++;
        }
        System.out.println("------i is"+i);*/
        byte[] buff = new byte[1024];
        int len = 0;
        if((len = inputStream.read(buff)) != -1) {
            buffer.append(new String(buff, 0, len));
        }
        if (buffer.length() > 0) {
            String msg = buffer.toString();
            System.out.println("------msg is :\n" + msg);
            method = msg.substring(0, msg.indexOf("/") - 1);
            System.out.println("------method is：" + method);
            uri = msg.substring(msg.indexOf("/"), msg.indexOf("HTTP/1.1") - 1);
            System.out.println("------uri is" + uri);
            if ("GET".equals(method) && uri.contains("?")) {
                String paramStr = uri.substring(uri.indexOf("?") + 1);
                System.out.println("------paramStr is:" + paramStr);
                String[] params = paramStr.split("&");
                for (String str : params) {
                    String[] values = str.split("=");
                    paramMap.put(values[0], values[1]);
                }
                System.out.println("------paramMap is:" + paramMap.toString());
            } else if ("POST".equals(method)) {
                String paramStr = buffer.substring(buffer.lastIndexOf("\r") + 1);
                if (null != paramStr && !("").equals(paramStr)) {
                    String[] params = paramStr.split("&");
                    for (String str : params) {
                        String[] values = str.split("=");
                        paramMap.put(values[0], values[1]);
                    }
                    System.out.println("------paramMap is:" + paramMap.toString());
                }
            }
        }

    }

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public Map<String, Object> getParamMap() {
        return paramMap;
    }

    public void setParamMap(Map<String, Object> paramMap) {
        this.paramMap = paramMap;
    }

    /**
     * 获取请求值
     * @param key
     * @return
     */
    public Object getParamter(String key){
        Set<Map.Entry<String,Object>> entrySet =  paramMap.entrySet();
        for(Map.Entry<String,Object> entry:entrySet){
            if(entry.getKey().equals(key)){
                return entry.getValue();
            }
        }
        return null;
    }

}

