package com.tomcat.test;

public class StaticResourceProcessor {

    public void process(HttpRequest request,HttpResponse response){
        response.writeFile(request.getUri());
    }
}
