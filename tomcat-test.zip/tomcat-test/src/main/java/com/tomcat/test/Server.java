package com.tomcat.test;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

    public static void main(String[] argc) throws IOException {
        ServerSocket serverSocket = null;
        try {
            serverSocket = new ServerSocket(8888);
            System.out.println("服务器初始完毕.........");
            while (true) {
                Socket socket = serverSocket.accept();
                new Thread(new ThreadHandler(socket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if(null != serverSocket) serverSocket.close();
        }
    }
}
