package com.tomcat.test;

import java.io.IOException;

public abstract class HttpServlet {
    private void init() {

    }

    public abstract void service(HttpRequest httpRequest,HttpResponse httpResponse) throws IOException;
}
