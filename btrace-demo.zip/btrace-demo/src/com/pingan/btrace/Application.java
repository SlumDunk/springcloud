package com.pingan.btrace;

import java.util.concurrent.atomic.AtomicLong;

/**
 * @descriptioin
 * @date 上午10:58:41 2018年4月25日
 * @author EX-LIUZERONG001
 */
public class Application {

	private static AtomicLong number = new AtomicLong(1l);

	/**
	 * @description:
	 * @date: 上午10:58:41 2018年4月25日
	 * @author: EX-LIUZERONG001
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Thread.sleep(30000l);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (int i = 1; i < 20; i++) {
			new Thread(new Runnable() {

				@Override
				public void run() {
					// TODO Auto-generated method stub
					System.out.println("start thread-" + number.getAndAdd(1l));
				}
			}).start();
			try {
				Thread.sleep(5000l);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}
