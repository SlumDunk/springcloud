package com.pingan.btrace;

import com.sun.btrace.BTraceUtils;
import com.sun.btrace.annotations.BTrace;
import com.sun.btrace.annotations.OnMethod;

/**
 * @descriptioin btrace for test
 * @date 上午10:47:31 2018.04.25
 * @author EX-LIUZERONG001
 */
@BTrace
public class TraceHelloWorld {
	@OnMethod(clazz = "java.lang.Thread", method = "start")
	public static void onThreadStart() {
		BTraceUtils.println("thread start!");
	}
}
